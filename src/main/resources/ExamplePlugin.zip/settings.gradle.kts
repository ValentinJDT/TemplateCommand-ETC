
rootProject.name = "ExamplePlugin"

