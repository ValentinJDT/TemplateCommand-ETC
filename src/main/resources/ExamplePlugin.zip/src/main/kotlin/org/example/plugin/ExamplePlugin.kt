package org.example.plugin

import fr.valentin.lib.vallib.plugin.Command

class ExamplePlugin: Plugin("name", "An optional description") {

    override fun onEnable() {
        println("$name enabled")
    }

    override fun onDisable() {
        println("$name disabled")
    }

}