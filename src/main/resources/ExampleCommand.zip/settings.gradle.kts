
rootProject.name = "ExampleCommand"

