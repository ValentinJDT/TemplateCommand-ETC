plugins {
    kotlin("jvm") version "1.8.20"
}

group = "org.example.plugin.command"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
    maven {
        url = uri("https://jitpack.io")
    }
}

dependencies {
    implementation("com.github.ValentinJDT:ValLib:v0.1.3")
}

kotlin {
    jvmToolchain(17)
}