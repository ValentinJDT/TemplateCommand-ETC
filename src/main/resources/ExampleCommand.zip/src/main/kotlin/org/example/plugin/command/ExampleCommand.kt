package org.example.plugin.command

import fr.valentin.api.plugin.Command

class ExampleCommand: Command("example") {

    override fun onEnable() {
        println("$name enabled")
    }

    override fun onDisable() {
        println("$name disabled")
    }

    override fun execute(args: List<String>) {
        println("Hello World !")
    }

}